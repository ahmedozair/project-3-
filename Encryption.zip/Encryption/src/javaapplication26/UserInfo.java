/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication26;
import java.util.*;


/**
 *
 * @author moyos
 */
public class UserInfo {
    
    
    //store the user info 
    HashMap<String,String>info=new HashMap<>();
    
    UserInfo(){
        
        info.put("this", "this");//used for texting
    }
        
    public HashMap getInfo(){//returns the user info when called 
        return info;
    }
    
    
}
